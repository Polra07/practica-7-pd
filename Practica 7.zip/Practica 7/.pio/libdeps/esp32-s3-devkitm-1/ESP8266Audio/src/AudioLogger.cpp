
#include "AudioLogger.h"

DevNullOut silencedLogger;
Print* audioLogger = &silencedLogger;
