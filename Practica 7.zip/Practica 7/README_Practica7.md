📄 README – Reproductor AAC en ESP32-S3
Este proyecto permite reproducir un archivo de audio en formato AAC desde la memoria flash interna de una ESP32-S3 mediante la interfaz I2S.

⚙️ Características
Reproduce audio AAC embebido en la flash (sampleaac.h)

Usa las librerías:

AudioFileSourcePROGMEM

AudioGeneratorAAC

AudioOutputI2S

Reinicia la reproducción automáticamente al finalizar

🧠 Funcionamiento
En setup() se inicializan:

La entrada de audio (in)

El decodificador AAC (aac)

La salida I2S (out)

Se llama aac->begin(in, out) para comenzar la reproducción.

En loop() se mantiene el audio en reproducción con aac->loop().

Si la reproducción termina, se reinicia automáticamente tras 1 segundo.

🔌 Pines I2S configurados
Señal	Pin
BCLK	36
LRCK	35
DATA	18

🧾 Requisitos
ESP32-S3

Archivo sampleaac.h generado previamente con un audio AAC

Librerías del proyecto ESP8266Audio (adaptadas a ESP32)

