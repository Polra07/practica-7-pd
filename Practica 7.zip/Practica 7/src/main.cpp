#include <Arduino.h>
#include "AudioGeneratorAAC.h"
#include "AudioOutputI2S.h"
#include "AudioFileSourcePROGMEM.h"
#include "sampleaac.h"



// Declaración de punteros a objetos de audio
AudioFileSourcePROGMEM *in;
AudioGeneratorAAC *aac;
AudioOutputI2S *out;

void setup() {
    Serial.begin(115200);

    // Inicialización de objetos de audio
    in = new AudioFileSourcePROGMEM(sampleaac, sizeof(sampleaac));
    aac = new AudioGeneratorAAC();
    out = new AudioOutputI2S();

    // Configuración de salida I2S
    out->SetGain(0.125);
    out->SetPinout(36, 35, 18);

    // Iniciar la reproducción del audio
    aac->begin(in, out);
}

void loop() {
    // Verificar si la reproducción está corriendo
    if (aac->isRunning()) {
        aac->loop();
    } else {
        Serial.println("Reproducción finalizada. Reiniciando...");
        aac->stop();
        delay(1000);  // Pausa antes de reiniciar
        aac->begin(in, out);  // Reiniciar la reproducción sin destruir objetos
    }
}
